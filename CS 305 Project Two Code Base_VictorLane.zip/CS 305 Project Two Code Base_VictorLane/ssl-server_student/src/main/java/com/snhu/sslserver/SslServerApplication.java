package com.snhu.sslserver;

// These generate the SHA-256 checksum
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	// creates the /hash endpoint that will return a checksum
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		String data = "Victor Lane - Artemis Financial checksum verification";

		// create MessageDigest object using the SHA-256 algorithm
		MessageDigest digest = MessageDigest.getInstance("SHA-256");

		// generates the SHA-256 hash as a byte array
		byte[] hash = digest.digest(data.getBytes());

		// this is used to build the hexadecimal checksum
		StringBuilder hexString = new StringBuilder();

		// converting each byte of the hash into a 2 char hexadecimal
		for (byte b : hash) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}

		// returning results as html page
		return "<h2>Artemis Financial Secure Checksum Verification</h2>"
				+ "<p><strong>Data:</string> " + data + "</p>"
				+ "<p><strong>Algorithm:</strong> SHA-256</p>"
				+ "<p><strong>Checksum:</strong> " + hexString.toString() + "</p>";
	}

}
